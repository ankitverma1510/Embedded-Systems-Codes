#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node{
int task_id;
char priority_color[10];
int priority;
};

void show(struct node p[], int size)
{
     for (int i=0;i<size;i++)
     {
        printf("Task_Id: %d , Priority_color: %s, Priority: %d\n", p[i].task_id,p[i].priority_color,p[i].priority);
     }
}

void swap(struct node *a, struct node *b)
{
    struct node temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

int left(int i)
{
    return (2*i+1);
}

int right(int i)
{
    return (2*i+2);
}

int parent(int i)
{
    return (i-1)/2;
}

void MinHeapify(int i, int heap_size, struct node p[])
{
    int l=left(i);
    int r=right(i);
    int smallest = i;
    if (l<heap_size &&  p[l].priority < p[smallest].priority)
        smallest = l;

    if (r<heap_size &&  p[r].priority < p[smallest].priority)
        smallest = r;

    if (p[smallest].priority!=p[i].priority)
    {   swap(&p[i],&p[smallest]);
        MinHeapify(smallest, heap_size, p);
    }

}

struct node extractMin( int heap_size, struct node harr[]) {

    if (heap_size <= 0)
    {
        struct node q;
        q.priority=-1;
        q.task_id = 0;
        strcpy(q.priority_color,"NA");
        return q;
    }
    else if (heap_size == 1)
    {
        heap_size--;
        return harr[0];
    }
    else{
    // Store the minimum value, and remove it from heap
    struct node root = harr[0];
    harr[0] = harr[heap_size - 1];
    heap_size--;
    MinHeapify(0, heap_size, harr);
    return root;
    }
  }




void show_node(struct node p)
{
    printf("\nTask_Id: %d , Priority_color: %s, Priority: %d\n", p.task_id,p.priority_color,p.priority);

}




int main(){
    struct node tasks[200];
    char temp[20];
    printf("Loading tasks list\n");
    FILE* fp = fopen("pending_tasks.csv","r");
    if (!fp)
        printf("Can't open file\n");
    else
        printf("File opened\n");
    char buff[1024];
    int col = 0;
    int row = 0;
    int i=0;
    while (fgets(buff,1024,fp))         //Reading csv file
    {
        col=0;
        row++;
        if (row==1)
            continue;
        char *value = strtok(buff,",");
        while (value)
        {
            if (col == 0)
                strcpy(temp, value);
                tasks[i].task_id=atoi(temp);
            if (col == 1)
                strcpy(tasks[i].priority_color, value);
            if (col == 2)
                strcpy(temp, value);
                tasks[i].priority=atoi(temp);
            value = strtok(NULL, ",");
            col++;
        }
        i++;
        //printf("%d",i);
    }
    fclose(fp);
    int heap_size=i;
    show(tasks, heap_size);
    printf("Data read finished\n\n");
    //swap(&tasks[2],&tasks[3]);
    //show(tasks);
    //reprioritizing
    for (int j =0; j < heap_size;j++)
    {
        if (strcmp(tasks[j].priority_color,"blue")==0)
            tasks[j].priority+=300;
        if (strcmp(tasks[j].priority_color,"green")==0)
            tasks[j].priority+=600;
        if (strcmp(tasks[j].priority_color,"yellow")==0)
            tasks[j].priority+=900;
    }
    printf("\n Reprioritized list \n");
    show(tasks, heap_size);
    printf("\n\n\n\n");


    for(int k = heap_size/2 - 1 ; k>=0; k--)
    {
        MinHeapify(k, heap_size, tasks);
    }

    show(tasks, heap_size);
    int remaining_elements=heap_size;
    for(int a=0;a<heap_size;a++)
    {
        struct node b = extractMin(remaining_elements, tasks);
        show_node(b);
        remaining_elements--;
    }
    //struct node a = extractMin(heap_size,tasks);
    //show_node(a);

    return 0;

}
